package com.example.abhishekpatel.rockpaper;

public class Data {

    String name;
    String value;
    String status;

    public Data(String name, String value, String status) {
    }

    public void Data(String name, String value, String status){
        this.name = name;
        this.value = value;
        this.status = status;
    }
}
